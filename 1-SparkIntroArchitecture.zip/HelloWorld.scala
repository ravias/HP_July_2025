// Comments in a Scala program
// Scala supports single-line and multi-line comments very similar to Java. 
// Scala program file. Compiling and running

object HelloWorld { 
/* This is my first program.
 * This will print 'Hello World' as the output
*/
    def main(args: Array[String]) {
        println("Hello, world!") // prints Hello World
    }
}